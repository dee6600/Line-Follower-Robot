
#define ref 0x40


void adc_init(void);
unsigned int adc_read(unsigned char);
#include<i3indya/adc.c>